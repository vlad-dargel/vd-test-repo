In very broad terms probabilistic data structures (PDS) allow us to get to a "close enough" result in a much shorter time and by using significantly less memory.

[linkTheSamePage](redisinsight:_?tutorialId=ds-json-create)

[link2WorkbenchPageWithTutorial](redisinsight:workbench?tutorialId=ds-json-intro)

[link3InvalidPage](redisinsight:invalidPage?tutorialId=ds-json-intro)

[link4InvalidTutorial](redisinsight:invalidPage?tutorialId=invalid-tutorial)

[link5JustWorkbenchPage](redisinsight:workbench)

[link6JustTheSamePage](redisinsight:_)
